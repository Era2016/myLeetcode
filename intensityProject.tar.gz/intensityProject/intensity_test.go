package intensityProject

import "testing"

func TestAdd(t *testing.T) {
	is := IntensitySegment{}
	is.toString()
	is.add(10, 30, 1)
	is.toString()

	is.add(20, 40, 1)
	is.toString()

	is.add(10, 40, -2)
	is.toString()
}
