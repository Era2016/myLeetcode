package intensityProject

import (
	"fmt"
	"sort"
	"sync"
)

type IntensitySegments interface {
	add(from, to, amount int)
	set(from, to, amount int)
	toString()
}

// save different partitioned intervals
type interval struct {
	// inter[0] means start
	// inter[1] means end
	inter [2]int
}

// fill the [begin, end] interval, as the mapping key
func obtainInterval(begin, end int) *interval {
	return &interval{
		inter: [2]int{
			begin, end,
		},
	}
}

type IntensitySegment struct {
	rw sync.RWMutex

	// save (interval, value) mappings
	intensityMapping map[*interval]int
}

/*func (is *IntensitySegment) merge() {
	is.rw.Lock()
	defer is.rw.Unlock()

	intervals := make([]*interval, 0, len(is.intensityMapping))
	for k := range is.intensityMapping {
		intervals = append(intervals, k)
	}
	sort.Slice(intervals, func(i, j int) bool {
		return (*intervals[i]).inter[0] < (*intervals[j]).inter[0]
	})
}*/

func (is *IntensitySegment) add(from, to, amount int) {
	is.rw.Lock()
	defer is.rw.Unlock()
	if amount == 0 {
		return
	}

	if is.intensityMapping == nil {
		is.intensityMapping = make(map[*interval]int, 0)
		is.intensityMapping[&interval{inter: [2]int{from, to}}] = amount
		return
	}

	tmpMapping := make(map[*interval]int)
	intervals := is.formatOrder()
	done := false
	for _, v := range intervals {
		start, end := v.inter[0], v.inter[1]
		if end < from {
			tmpMapping[v] = is.intensityMapping[v]
		} else if start > to {
			if !done {
				tmpMapping[&interval{inter: [2]int{from, to}}] = amount
				done = true
			}

			tmpMapping[v] = is.intensityMapping[v]
		} else {
			val := is.intensityMapping[v]
			// fill the [begin, end] interval, as the mapping key
			fillInterval := func(begin, end int) *interval {
				return &interval{
					inter: [2]int{
						begin, end,
					},
				}
			}
			if start < from {
				if end > from && end < to {
					tmpMapping[fillInterval(start, from)] = val
					tmpMapping[fillInterval(from, end)] = val + amount
					//tmpMapping[fillInterval(end, to)] = amount

				} else if end >= to {
					tmpMapping[fillInterval(start, from)] = val
					tmpMapping[fillInterval(from, to)] = val + amount
					//if end != to {
					//	tmpMapping[fillInterval(to, end)] = val
					//}
				}
			} else { // start >= from
				if end >= from && end < to {
					if from != start {
						tmpMapping[fillInterval(from, start)] = amount
					}
					tmpMapping[fillInterval(start, end)] = val + amount
					//tmpMapping[fillInterval(end, to)] = amount
				} else if end >= to {
					if from != start {
						tmpMapping[fillInterval(from, start)] = amount
					}
					tmpMapping[fillInterval(start, to)] = val + amount
					//if to != end {
					//	tmpMapping[fillInterval(to, end)] = val
					//}
				}
			}

			// we need the one bigger interval, to continue calculating
			// before this interval, we had calculated
			sorted := []int{from, to, start, end}
			sort.Ints(sorted)
			from, to = sorted[2], sorted[3]
		}
	}

	is.intensityMapping = tmpMapping
}

func (is *IntensitySegment) set(from, to, amount int) {
	is.rw.Lock()
	defer is.rw.Unlock()

	if is.intensityMapping == nil {
		is.intensityMapping = make(map[*interval]int, 0)
	}
	tmpMapping := make(map[*interval]int)
	done := false
	intervals := is.formatOrder()
	for _, v := range intervals {
		start, end := v.inter[0], v.inter[1]
		if end < from {
			tmpMapping[v] = amount
		} else if start > to {
			if !done {
				tmpMapping[obtainInterval(from, to)] = amount
				done = true
			}
			tmpMapping[v] = amount
		} else {
			// from = min(from, start)
			// to = max(to, end)
			if start < from {
				from = start
			}
			if end > to {
				to = end
			}
		}
	}
	if !done {
		tmpMapping[obtainInterval(from, to)] = amount
	}

	is.intensityMapping = tmpMapping
}

func (is *IntensitySegment) toString() {
	is.rw.RLock()
	defer is.rw.RUnlock()

	if len(is.intensityMapping) == 0 {
		fmt.Println("[]")
		return
	}
	// intervals := make([]*interval, 0, len(is.intensityMapping))
	// for k := range is.intensityMapping {
	// 	intervals = append(intervals, k)
	// }
	// sort.Slice(intervals, func(i, j int) bool {
	// 	return (*intervals[i]).inter[0] < (*intervals[j]).inter[0]
	// })
	intervals := is.formatOrder()

	str := "["
	var start int
	for _, v := range intervals {
		start = (*v).inter[0]
		str += fmt.Sprintf("[%d, %d],", start, is.intensityMapping[v])
	}

	str += fmt.Sprintf("[%d, 0]]", intervals[len(intervals)-1].inter[1])
	fmt.Println(str)
}

// output the mapping key in order
func (is *IntensitySegment) formatOrder() []*interval {
	intervals := make([]*interval, 0, len(is.intensityMapping))
	for k := range is.intensityMapping {
		intervals = append(intervals, k)
	}
	sort.Slice(intervals, func(i, j int) bool {
		return (*intervals[i]).inter[0] < (*intervals[j]).inter[0]
	})
	return intervals
}
